import Api from "./api"

class BillingServiceImpl {

    Api = Api;

}

export const BillingService = new BillingServiceImpl();