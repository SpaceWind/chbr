/*@flow*/
import {BillingService} from "../actions/api/billing";

export default class BillingService
{
    private state;
    constructor (state)
    {
        this.state = state;
    }


}